const ENV = {
    API_URL: process.env.REACT_APP_API_URL,
    ENV_MODE: process.env.REACT_APP_ENV
}

export default ENV;

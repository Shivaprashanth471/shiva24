import React, { PropsWithChildren } from 'react';
import Button from '@material-ui/core/Button';
import DialogActions from '@material-ui/core/DialogActions';
import DialogTitle from '@material-ui/core/DialogTitle';

export interface VitawerksConfirmComponentProps{
    confirmationText:any;
    cancel:any;
    confirm:any;
    notext:string;
    yestext:string;
}

const VitawerksConfirmComponent = (props: PropsWithChildren<VitawerksConfirmComponentProps>) => {
    return <div>
        <DialogTitle id="alert-dialog-slide-title"
            className={'alert-dialog-slide-title'}>{props?.confirmationText || 'Confirm ?'}</DialogTitle>
        {/*<DialogContent>*/}
        {/*    <DialogContentText id="alert-dialog-slide-description">*/}
        {/*        Let Google help apps determine location. This means sending anonymous location data to*/}
        {/*        Google, even when no apps are running.*/}
        {/*    </DialogContentText>*/}
        {/*</DialogContent>*/}
        <DialogActions className={'pdd-20'}>
            <Button onClick={props?.cancel} variant={"contained"} color={'default'}>
                {props?.notext || 'No, Cancel'}
            </Button>
            <Button onClick={props?.confirm} variant={"contained"} color={'primary'}>
                {props?.yestext || 'Yes, Confirm'}
            </Button>
        </DialogActions>
    </div>;
}

export default VitawerksConfirmComponent;
import * as auth from "./auth.action";
import * as other from "./others.action";
import * as domains from "./domains.action";
import * as polling from "./polling.action";

export {
    auth,
    other,
    domains,
    polling
};

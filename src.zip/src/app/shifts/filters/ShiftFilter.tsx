import { Button, Chip, DialogActions, DialogContent, DialogTitle, FormLabel } from '@material-ui/core';
import React, { PropsWithChildren } from 'react';
import Autocomplete from "@material-ui/lab/Autocomplete";
import TextField from "@material-ui/core/TextField";
import DatePickers from "react-multi-date-picker";
import DatePanel from "react-multi-date-picker/plugins/date_panel";
import { AllShiftStatusList, SomeShiftStatusList, shiftType } from "../../../constants/data";
import './ShiftFilter.scss'
import { nanoid } from 'nanoid'
import moment from 'moment';

export interface ShiftFilterProps {
    cancel: () => void,
    confirm: () => void,
    hcpTypes: any,
    facilityList: any,
    hcpTypeRef?: any,
    valueRef?: any,
    statusRef?: any,
    facilityIdRef: any,
    timeTypeRef: any,
    noStatus?: boolean;

    isMaster?: boolean;
    isCompleted?: boolean;
    isRequired?: boolean;

    setValueRef?: any,
    setStatusRef?: any,
    setHcpTypeRef: any,
    setTimeTypeRef: any,
    setFacilityIdRef: any,
    resetFilters: any;

    regions?: any;
    selectedRegion?: any;
    setSelectedRegion?: any

    selectedHcps?: any;
    setSelectedHcps?: any;
    selectedTimeTypes?: any;
    selectedStatusTypes?: any;
    setSelectedTimeTypes?: any;
    selectedFaciltities?: any;
    setSelectedFacilities?: any;
    setSelectedStatusTypes?: any;
}

const ShiftFilter = (props: PropsWithChildren<ShiftFilterProps>) => {
    const afterConfirm = props?.confirm;
    const afterCancel = props?.cancel;
    const hcpTypes = props?.hcpTypes;
    const regions = props?.regions;
    const selectedRegion = props?.selectedRegion;
    const setSelectedRegion = props?.setSelectedRegion;
    const isMaster = props?.isMaster
    const setHcpTypeRef = props?.setHcpTypeRef;
    const hcpTypeRef = props?.hcpTypeRef;
    const statusList = props?.isMaster ? AllShiftStatusList : SomeShiftStatusList
    const setStatusRef = props?.setStatusRef;
    const facilityIdRef = props?.facilityIdRef;

    const setValueRef = props?.setValueRef;
    const statusRef = props?.statusRef;
    const facilityList = props?.facilityList;
    const setFacilityIdRef = props?.setFacilityIdRef;
    const timeTypeRef = props?.timeTypeRef;
    const setTimeTypeRef = props?.setTimeTypeRef
    const resetFilters = props?.resetFilters
    const noStatus = props?.noStatus
    const isCompleted = props?.isCompleted
    const isRequired = props?.isRequired

    const selectedHcps = props?.selectedHcps
    const setSelectedHcps = props?.setSelectedHcps
    const selectedTimeTypes = props?.selectedTimeTypes
    const selectedStatusTypes = props?.selectedStatusTypes
    const setSelectedTimeTypes = props?.setSelectedTimeTypes
    const selectedFaciltities = props?.selectedFaciltities
    const setSelectedFacilities = props?.setSelectedFacilities
    const setSelectedStatusTypes = props?.setSelectedStatusTypes

    const handleDatePicker = (value: any) => {
        let shift_dates = value?.map((item: any) => {
            let mm = item?.month?.number
            let dd = item?.day
            let yyyy = item?.year
            return moment(`${yyyy}-${mm}-${dd}`).format('YYYY-MM-DD')
        })
        setValueRef(shift_dates)
    }

    const formatDateFieldLabel = () => {
        if (isCompleted) {
            return "Shift Completed Date"
        } else if (isRequired) {
            return "Shift Required Date"
        } else {
            return "Shift Date"
        }
    }

    const handleFacilityDelete = (chip: any) => {
        let filterdChips = selectedFaciltities?.filter((item: any) => item?.key !== chip?.key)
        setSelectedFacilities(filterdChips)

    }

    const handleHcpDelete = (chip: any) => {
        let filterdChips = selectedHcps?.filter((item: any) => item?.key !== chip?.key)
        setSelectedHcps(filterdChips)

    }

    const handleStatusDelete = (chip: any) => {
        let filterdChips = selectedStatusTypes.filter((item: any) => item?.key !== chip?.key)
        setSelectedStatusTypes(filterdChips)

    }

    const handleTimeTypeDelete = (chip: any) => {
        let filterdChips = selectedTimeTypes?.filter((item: any) => item?.key !== chip?.key)
        setSelectedTimeTypes(filterdChips)

    }



    return <div className="pdd-30 pdd-top-40 facility-filters">
        <div className="dialog-header d-flex">
            <DialogTitle id="alert-dialog-title">Filters</DialogTitle>
            <Button onClick={() => {
                resetFilters()
                afterCancel()
            }} color="secondary" id="btn_reset_filter">
                {'Reset'}
            </Button>
        </div>
        <DialogContent>
            <div className="form-field">
                <FormLabel className={'form-label'}>Select Region</FormLabel>
                {facilityList !== null ? <Autocomplete
                    options={regions}
                    getOptionLabel={(option: any) => option.name}
                    placeholder={"Select Region"}
                    id="input_select_regions"
                    className="mrg-top-10"
                    onChange={($event, value) => {
                        setSelectedRegion(value?.code)
                    }
                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            id='select_region'
                            variant='outlined'
                            placeholder={"Select Region"}
                            value={selectedRegion}
                        />
                    )}
                /> : <></>}
            </div>
            <div className="form-field mrg-top-20">
                <FormLabel className={'form-label'}>Select Facility</FormLabel>
                {facilityList !== null ? <Autocomplete
                    options={facilityList}
                    getOptionLabel={(option: any) => option.facility_name}
                    placeholder={"Select facility"}
                    id="input_select_facType"
                    className="mrg-top-10"
                    onChange={($event, value) => {
                        setFacilityIdRef(value?._id)
                        let isUnique = selectedFaciltities?.some((item: any) => item?.key === value?._id)

                        if (!isUnique) {
                            if (value?._id) {
                                let newSelected = {
                                    key: value?._id,
                                    label: value?.facility_name
                                }

                                setSelectedFacilities([...selectedFaciltities, newSelected])
                            }

                        }
                    }
                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            id='select_facType'
                            variant='outlined'
                            placeholder={"Select Facility"}
                            value={facilityIdRef.current}
                        />
                    )}
                /> : <></>}
                {
                    selectedFaciltities.length > 0 && <p className="hcp-chips">{selectedFaciltities?.map((data: any) => <Chip
                        key={data.key}
                        label={data.label}
                        onDelete={() => handleFacilityDelete(data)}
                    />)}</p>
                }

            </div>
            <div className="form-field mrg-top-20">
                <FormLabel className={'form-label'}>{('Select HCP Type')}</FormLabel>
                {hcpTypes !== null ? <Autocomplete
                    options={hcpTypes}
                    getOptionLabel={(option: any) => option.name}
                    placeholder={"Select Hcp Type"}
                    id="input_select_hcpType"
                    className="mrg-top-10"
                    onChange={($event, value) => {
                        setHcpTypeRef(value?.code)
                        let isUnique = selectedHcps.some((item: any) => item?.label === value?.code)
                        if (!isUnique) {
                            if (value?.code) {
                                let newSelected = {
                                    key: nanoid(),
                                    label: value?.code
                                }
                                setSelectedHcps([...selectedHcps, newSelected])
                            }
                        }
                    }
                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            id='select_hcpType'
                            variant='outlined'
                            placeholder={"Select Hcp Type"}
                            value={hcpTypeRef.current}
                        />
                    )}
                /> : <></>}
                <p className="hcp-chips">{selectedHcps?.map((data: any) => <Chip
                    key={data.key}
                    label={data.label}
                    onDelete={() => handleHcpDelete(data)}
                />)}</p>
            </div>
            {
                !noStatus && <div className="form-field mrg-top-20">
                    <FormLabel className={'form-label'}>Status</FormLabel>
                    <Autocomplete
                        options={statusList}
                        getOptionLabel={(option: any) => option.name}
                        placeholder={"Select Status"}
                        id="input_select_status"
                        className="mrg-top-10"
                        onChange={($event, value) => {
                            setStatusRef(value?.code)
                            if (isMaster) {
                                let isUnique = selectedStatusTypes.some((item: any) => item?.label === value?.code)
                                if (!isUnique) {
                                    if (value?.code) {
                                        let newSelected = {
                                            key: nanoid(),
                                            label: value?.code
                                        }
                                        setSelectedStatusTypes([...selectedStatusTypes, newSelected])
                                    }
                                }
                            }

                        }
                        }
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                id='select_status'
                                variant='outlined'
                                value={statusRef.current}
                                placeholder={"Select Status"}
                                fullWidth
                            />
                        )}
                    />

                    {
                        isMaster && selectedStatusTypes.length > 0 && <p className="hcp-chips">{selectedStatusTypes?.map((data: any) => <Chip
                            key={data.key}
                            label={data.label}
                            onDelete={() => handleStatusDelete(data)}
                        />)}</p>
                    }
                </div>
            }
            <div className="form-field mrg-top-20">
                <FormLabel className={'form-label'}>{formatDateFieldLabel()}</FormLabel>
                <div className="mrg-top-10">
                    <DatePickers
                        required
                        inputClass='custom-input'
                        className="rmdp-prime"
                        plugins={[
                            <DatePanel />
                        ]}
                        format="MM/DD/YYYY"
                        range={true}

                        onChange={handleDatePicker}
                        placeholder={"Select Date"}
                        id='input_shift_requirement_shift_datepicker'
                        name="shift_dates"
                    />
                </div>
                <div className="form-field mrg-top-20">
                    <FormLabel className={'form-label'}>Time Type</FormLabel>
                    {shiftType !== null ? <Autocomplete
                        options={shiftType}
                        getOptionLabel={(option: any) => option.label}
                        placeholder={"Select Time Type"}
                        id="input_select_timeType"
                        className="mrg-top-10"
                        onChange={($event, value) => {
                            setTimeTypeRef(value?.value)
                            let isUnique = selectedHcps.some((item: any) => item?.label === value?.value)
                            if (!isUnique) {
                                if (value?.value) {
                                    let newSelected = {
                                        key: nanoid(),
                                        label: value?.value
                                    }
                                    setSelectedTimeTypes([...selectedTimeTypes, newSelected])
                                }
                            }
                        }
                        }
                        renderInput={(params) => (
                            <TextField
                                {...params}
                                id='select_timeType'
                                variant='outlined'
                                placeholder={"Select Time Type"}
                                value={timeTypeRef.current}
                            />
                        )}
                    /> : <></>}
                    <p className="hcp-chips">{selectedTimeTypes?.map((data: any) => <Chip
                        key={data.key}
                        label={data.label}
                        onDelete={() => handleTimeTypeDelete(data)}
                    />)}</p>


                </div>
            </div>
        </DialogContent>
        <DialogActions className="mrg-top-40">
            <Button onClick={afterCancel} color="secondary" variant='outlined' id="btn_cancel_filter">
                {'Cancel'}
            </Button>
            <Button onClick={() => {
                afterConfirm()
            }} id="btn_reject_application" className={"submit mrg-left-20"} variant={"contained"} color="primary" autoFocus>
                {'Apply'}
            </Button>
        </DialogActions>
    </div>;
}

export default ShiftFilter;
import { Button, Chip, DialogActions, DialogContent, DialogTitle, FormLabel } from '@material-ui/core';
import TextField from "@material-ui/core/TextField";
import Autocomplete from "@material-ui/lab/Autocomplete";
import moment from 'moment';
import { nanoid } from 'nanoid'
import React, { PropsWithChildren } from 'react';
import DatePickers from "react-multi-date-picker";
import DatePanel from "react-multi-date-picker/plugins/date_panel";
import "react-multi-date-picker/styles/layouts/mobile.css";
import "./FacilityFiltersComponent.scss";

export interface FacilityFiltersComponentProps {
    cancel: () => void,
    confirm: () => void,
    setStatusRef: any,
    setRegionRef: any,
    regionList: any,
    setValueRef: any;
    status: any;
    region: any;
    value?: any;
    selectedRegions?: any;
    setSelectedRegions?: any;
    resetFilters: any;
}


const FacilityFiltersComponent = (props: PropsWithChildren<FacilityFiltersComponentProps>) => {
    const afterConfirm = props?.confirm;
    const afterCancel = props?.cancel
    const statusList = [{ name: "Active", code: true }, { name: "Inactive", code: false }]
    const setStatusRef = props?.setStatusRef;
    const setRegionRef = props?.setRegionRef;
    const regionList = props?.regionList;
    const status = props?.status;
    const region = props?.region;
    const setValueRef = props?.setValueRef;
    const selectedRegions = props?.selectedRegions
    const setSelectedRegions = props?.setSelectedRegions
    const resetFilters = props?.resetFilters;


    const handleDatePicker = (value: any) => {
        let shift_dates = value?.map((item: any) => {
            let mm = item?.month?.number
            let dd = item?.day
            let yyyy = item?.year
            return moment(`${yyyy}-${mm}-${dd}`).format('YYYY-MM-DD')
        })

        console.log(shift_dates)
        setValueRef(shift_dates)
    }

    const handleDelete = (chip: any) => {
        let filterdChips = selectedRegions.filter((item: any) => item?.key !== chip?.key)
        setSelectedRegions(filterdChips)

    }

    return <div className="pdd-30 pdd-top-40 facility-filters">

        <div className="dialog-header">
            <DialogTitle id="alert-dialog-title">Filters</DialogTitle>
            <Button onClick={() => {
                resetFilters()
                afterCancel()
            }} color="secondary" id="btn_reset_filter">
                {'Reset'}
            </Button>
        </div>


        <DialogContent>
            <div className="form-field">
                <FormLabel className={'form-label'}>{('Select Region')}</FormLabel>
                {regionList !== null ? <Autocomplete
                    options={regionList}
                    getOptionLabel={(option: any) => option.name}
                    placeholder={"Select Region"}
                    id="input_select_region"
                    className="mrg-top-10"
                    onChange={($event, value) => {
                        setRegionRef(value?.code)
                        let isUnique = selectedRegions.some((item: any) => item?.label === value?.code)

                        if (!isUnique) {
                            if (value?.code) {
                                let newSelected = {
                                    key: nanoid(),
                                    label: value?.code
                                }

                                setSelectedRegions([...selectedRegions, newSelected])
                            }

                        }
                    }


                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            id='select_region'
                            variant='outlined'
                            placeholder={"Select Region"}
                            value={region?.current}
                        />
                    )}
                /> : <></>}
                <p className="hcp-chips">{selectedRegions.map((data: any) => <Chip
                    key={data.key}
                    label={data.label}
                    onDelete={() => handleDelete(data)}
                />)}</p>
            </div>
            <div className="form-field mrg-top-20">
                <FormLabel className={'form-label'}>Status</FormLabel>
                <Autocomplete
                    options={statusList}
                    getOptionLabel={(option: any) => option.name}
                    placeholder={"Select Status"}
                    id="input_select_status"
                    className="mrg-top-10"
                    onChange={($event, value) =>
                        setStatusRef(value?.code)
                    }
                    renderInput={(params) => (
                        <TextField
                            {...params}
                            id='select_status'
                            variant='outlined'
                            value={status?.current}
                            placeholder={"Select Status"}
                            fullWidth
                        />
                    )}
                />

            </div>
            <div className="form-field mrg-top-20">
                <FormLabel className={'form-label'}>{('Created On')}</FormLabel>
                <div className="mrg-top-10">
                    <DatePickers
                        required
                        inputClass='custom-input'
                        plugins={[
                            <DatePanel />
                        ]}
                        format="MM/DD/YYYY"
                        range={true}
                        onChange={handleDatePicker}

                        placeholder={"Select Date"}
                        id='input_shift_requirement_shift_datepicker'
                        name="shift_dates"
                    />
                    {/* <DateRangeOutlined className='date-icon' fontSize='large' color='action' /> */}
                </div>
            </div>
        </DialogContent>
        <DialogActions className="mrg-top-40">

            <Button variant='outlined' onClick={() => {
                afterCancel()
            }} color="secondary" id="btn_cancel_filter">
                {'Cancel'}
            </Button>
            <Button onClick={afterConfirm} id="btn_reject_application" className={"submit mrg-left-20"} variant={"contained"} color="primary" autoFocus>
                {'Apply'}
            </Button>
        </DialogActions>
    </div>;
}

export default FacilityFiltersComponent;



import React from 'react';

const AddEmployeeComponent = () => {
    return <div></div>;
}

export default AddEmployeeComponent;
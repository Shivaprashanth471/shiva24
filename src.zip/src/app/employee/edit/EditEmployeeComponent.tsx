import React from 'react';

const EditEmployeeComponent = () => {
    return <div></div>;
}

export default EditEmployeeComponent;
import React, { useEffect } from 'react';
import ComingSoonComponent from '../../components/ComingSoonComponent';
import { Communications } from '../../helpers';
import './DashboardScreen.scss'

const DashboardScreen = () => {
    useEffect(() => {
        Communications.pageTitleSubject.next('Dashboard');
        Communications.pageBackButtonSubject.next(null);
    }, [])
    return <div className="dashboard">
        <ComingSoonComponent/>
    </div>;
}

export default DashboardScreen;
import React, { useCallback, useEffect, useState } from 'react';
import { useHistory, useParams, Link } from 'react-router-dom';
import { TsDataListOptions, TsDataListState, TsDataListWrapperClass } from '../../../../classes/ts-data-list-wrapper.class';
import { ENV } from '../../../../constants';
import { ApiService, CommonService, Communications } from '../../../../helpers';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
// import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import { Button, LinearProgress } from "@material-ui/core";
import NoDataCardComponent from '../../../../components/NoDataCardComponent';

const RemoveHcpsScreen = () => {
    const [list, setList] = useState<TsDataListState | null>(null);
    const params = useParams<{ id: string }>();
    const { id } = params;
    const history = useHistory();
    const [selectedHcps, setSelectedHcps] = React.useState<any>(null)
    const [isAllselected, setAllSelected] = React.useState<boolean>(false);
    const [groupDetails, setGroupDetails] = useState<any>(null);

    const init = useCallback(() => {
        if (!list) {
            const options = new TsDataListOptions({
                webMatColumns: ['HCP Name', 'HCP Type', 'Actions'],
                mobileMatColumns: ['HCP Name', 'HCP Type', 'Actions'],
            }, ENV.API_URL + 'group/' + id + '/member', setList, ApiService, 'get');

            let tableWrapperObj = new TsDataListWrapperClass(options)
            setList({ table: tableWrapperObj });
        }
    }, [list, id]);

    const RemoveHcpsToGroup = useCallback((hcp: any) => {
        delete hcp["checked"];
        return new Promise((resolve, reject) => {
            ApiService.delete(ENV.API_URL + 'group/' + id + '/member/' + hcp?._id).then((resp: any) => {
                if (resp && resp.success) {
                    resolve(null);
                    history.push('/group/view/' + id);
                } else {
                    reject(resp);
                }
            }).catch((err) => {
                reject(err);
            })
        })
    }, [history, id])

    const getDetails = useCallback(() => {
        CommonService._api.get(ENV.API_URL + 'group/' + id).then((resp) => {
            setGroupDetails(resp.data);
        }).catch((err) => {
            console.log(err)
        })
    }, [id])

    const handleSelectAll = (event: any) => {
        selectedHcps?.map((item: any) => {
            return (
                item.checked = event.target.checked
            )
        })
        setSelectedHcps(selectedHcps)
        setAllSelected(event.target.checked)
    }

    const handleSelectHcp = (event: any, index: any) => {
        selectedHcps[index].checked = event.target.checked
        setSelectedHcps([...selectedHcps])
    }

    const handleRemoveMembers = useCallback(() => {
        (selectedHcps || []).forEach((value: any) => {
            if (value?.checked === true) {
                RemoveHcpsToGroup(value)
            }
        })
    }, [selectedHcps, RemoveHcpsToGroup])

    useEffect(() => {
        let temp: any = []
        list?.table?.data?.forEach((item: any) => {
            item = { ...item, checked: false }
            temp.push(item)
        })
        setSelectedHcps(temp)
    }, [list])

    useEffect(() => {

    }, [isAllselected])


    useEffect(() => {
        init();
        getDetails()
        Communications.pageTitleSubject.next('Remove HCP');
        Communications.pageBackButtonSubject.next('/group/list');
    }, [init, getDetails])
    return (
        <>
            <div className={'group-view screen crud-layout pdd-30'}>
                {list && list.table?._isDataLoading && <div className="table-loading-indicator">
                    <LinearProgress />
                </div>}
                <div>
                    <div className="header mrg-bottom-0">
                        <div className="filter">
                            <div>
                                <h2>{groupDetails?.title}</h2>
                                <p>Total Members:{list?.table?.data?.length}</p>
                            </div>
                        </div>
                        <div className="actions">
                            <div className="">
                                
                            </div>
                        </div>
                    </div>
                </div>
                {list && list.table && <>
                    <TableContainer component={Paper} className={'table-responsive'}>
                        <Table stickyHeader aria-label="sticky table">
                            <TableHead>
                                <TableRow>
                                    <TableCell padding="checkbox">
                                        <input type="checkbox" onChange={(event) => handleSelectAll(event)} checked={isAllselected} id="cb_select_all_hcps" />
                                    </TableCell>
                                    {list?.table.matColumns.map((column: any, columnIndex: any) => (
                                        <TableCell className={(column === 'actions') ? 'min-width-cell' : ''}
                                            key={'header-col-' + columnIndex}
                                        >
                                            {column}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {list.table.canShowNoData() &&
                                    <NoDataCardComponent tableCellCount={list.table.matColumns.length} />
                                }
                                {list?.table.data.map((row: any, rowIndex: any) => {
                                    return (
                                        <TableRow hover role="checkbox" tabIndex={-1} key={'row-' + 1}>
                                            <TableCell>
                                                <input type={"checkbox"} checked={selectedHcps[rowIndex]?.checked} onChange={(event) => handleSelectHcp(event, rowIndex)} id={"cb_" + rowIndex} />
                                            </TableCell>
                                            <TableCell>
                                                {row['hcp_name']}
                                            </TableCell>
                                            <TableCell>
                                                {row['hcp_type']}
                                            </TableCell>
                                            <TableCell >
                                                <Link to={'/hcp/view/' + row.id} className="info-link" id={"link_hcp_details" + rowIndex} >
                                                    {('View Details')}
                                                </Link>
                                            </TableCell>
                                        </TableRow>
                                    );
                                })}
                            </TableBody>
                        </Table>
                        {/*<TablePagination*/}
                        {/*    rowsPerPageOptions={list.table.pagination.pageSizeOptions}*/}
                        {/*    component='div'*/}
                        {/*    count={list?.table.pagination.totalItems}*/}
                        {/*    rowsPerPage={list?.table.pagination.pageSize}*/}
                        {/*    page={list?.table.pagination.pageIndex}*/}
                        {/*    onPageChange={(event, page) => list.table.pageEvent(page)}*/}
                        {/*    onRowsPerPageChange={event => list.table?.pageEvent(0, +event.target.value)}*/}
                        {/*/>*/}
                    </TableContainer>
                </>}
                <div className="mrg-top-20 remove-members-wrapper">
                   <div className="d-flex">
                   <Button
                        size="large"
                        onClick={() => history.push('/group/view/' + id)}
                        variant={"outlined"}
                        color="secondary"
                        className="cancel"
                        id="btn_hcp_edit_cancel">Cancel</Button>
                    <Button variant={"contained"} className="actions" onClick={handleRemoveMembers}>Remove Members</Button>
                   </div>
                </div>
            </div>
        </>
    )
}


export default RemoveHcpsScreen;
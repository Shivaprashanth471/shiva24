import React from "react";

const BlastHistory = () => {
  return <div className="sms-blast-history">Blast History Screen</div>;
};

export default BlastHistory;
